cp validation.properties /home/ec2-user/ldbc_spb_bm_2.0/dist/
cd /home/ec2-user/ldbc_spb_bm_2.0/dist/
java -jar semantic_publishing_benchmark-basic-virtuoso.jar validation.properties 
