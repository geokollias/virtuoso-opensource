rm -f /1s?/dbs/spbval*
rm -f virtuoso.tdb virtuoso.log virtuoso.pxa 
