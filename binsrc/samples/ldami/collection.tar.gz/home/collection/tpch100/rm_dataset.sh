rm -rf /1s1/dbgen
