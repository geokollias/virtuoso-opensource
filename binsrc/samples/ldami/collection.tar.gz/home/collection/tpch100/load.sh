cd /home/ec2-user/virtuoso-opensource
. ./.profile
cd /home/ec2-user/virtuoso-opensource/binsrc/tests/tpc-h
sh load.sh 100
