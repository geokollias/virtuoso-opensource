rm -f /1s1/dbs/snb300* /1s2/dbs/snb300*
