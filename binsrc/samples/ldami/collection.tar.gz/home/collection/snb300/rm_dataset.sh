rm -rf /1s1/snb300data/*
