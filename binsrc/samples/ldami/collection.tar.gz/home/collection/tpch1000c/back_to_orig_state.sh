shopt -s extglob
rm !(clrefresh.sql.tpl|cluster.global.ini.tpl|cluster.ini.tpl|dbgen|init.sql|virtuoso|virtuoso.db|virtuoso.global.ini.tpl|virtuoso.ini|virtuoso.ini.tpl|back_to_orig_state.sh|README|dists.dss|ldschema.sql|ldfile.sql|schema.sql|clld.sql|tpc-h.sql|init_all.sh|load.sh|rm_dataset.sh|run.sh)

