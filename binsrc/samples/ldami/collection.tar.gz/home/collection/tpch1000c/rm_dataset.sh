ssh a1 rm -rf /1s1/tpch1000data/
ssh a2 rm -rf /1s1/tpch1000data/
