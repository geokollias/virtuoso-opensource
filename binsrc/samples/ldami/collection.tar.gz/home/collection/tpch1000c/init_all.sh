./virtuoso +wait
isql 1111 < init.sql
chmod +x *.sh
./init.sh
./cpexe.sh
