cl_setup (vector ('a1', 'a2'), 2, '/home/tpch1000r');

dbgen (vector ('a1', 'a2'), '/1s1/tpch1000data', 100, 32, 2, 18);
