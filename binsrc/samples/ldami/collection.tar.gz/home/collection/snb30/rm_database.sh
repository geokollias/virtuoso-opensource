rm -f /1s1/dbs/snb30* /1s2/dbs/snb30*
