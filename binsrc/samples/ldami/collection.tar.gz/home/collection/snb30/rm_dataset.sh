rm -rf /1s1/snb30data/*
