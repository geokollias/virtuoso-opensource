cp /home/ec2-user/virtuoso-opensource/binsrc/tests/tpc-h/dbgen/dbgen .
cp /home/ec2-user/virtuoso-opensource/binsrc/tests/tpc-h/dbgen/dists.dss .
sh dbgen.sh
