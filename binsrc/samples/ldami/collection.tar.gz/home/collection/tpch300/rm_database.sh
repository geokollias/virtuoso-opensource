rm -f /1s?/dbs/tpch300cp*.db
rm -f /1s2/dbs/virtuoso.trx
rm -f virtuoso.tdb virtuoso.log virtuoso.pxa 
