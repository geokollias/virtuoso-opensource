rm -rf /1s2/tpch300data
