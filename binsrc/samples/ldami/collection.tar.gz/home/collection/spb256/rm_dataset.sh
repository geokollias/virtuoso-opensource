rm -rf /1s2/spb256
