cd /1s2/spb256
java -jar semantic_publishing_benchmark-basic-virtuoso.jar spb256.properties 
