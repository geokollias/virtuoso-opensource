rm -f /1s?/dbs/spb256*
rm -f virtuoso.tdb virtuoso.log virtuoso.pxa 
