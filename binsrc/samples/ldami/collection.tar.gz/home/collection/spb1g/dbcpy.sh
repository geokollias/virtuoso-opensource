aws s3 cp spb1gdata.tar s3://opl-spb1gdataset/spb1gdata.tar
