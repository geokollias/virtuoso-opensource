rm -f /1s?/dbs/spb1g*
rm -f virtuoso.tdb virtuoso.log virtuoso.pxa 
