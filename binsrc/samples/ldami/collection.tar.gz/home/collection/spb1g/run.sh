cd /1s2/spb1g
java -jar semantic_publishing_benchmark-basic-virtuoso.jar spb1g.properties 
